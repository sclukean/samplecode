# Available samples and steps to run the samples

To see the currently available samples and how to run them, take a look at our [Run Samples guide](https://docs.scandit.com/data-capture-sdk/android/samples/run-samples.html).

If you want to learn more about the SDK, check out the complete documentation and getting started guides [here](https://docs.scandit.com/data-capture-sdk/android/).
