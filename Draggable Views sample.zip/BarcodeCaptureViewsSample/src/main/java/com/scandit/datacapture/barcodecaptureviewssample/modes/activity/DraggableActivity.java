package com.scandit.datacapture.barcodecaptureviewssample.modes.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

import androidx.lifecycle.ViewModelProvider;
import com.scandit.datacapture.barcode.data.Barcode;
import com.scandit.datacapture.barcode.data.SymbologyDescription;
import com.scandit.datacapture.barcode.ui.overlay.BarcodeCaptureOverlay;
import com.scandit.datacapture.barcodecaptureviewssample.R;
import com.scandit.datacapture.barcodecaptureviewssample.modes.ScanViewModel;
import com.scandit.datacapture.barcodecaptureviewssample.modes.base.CameraPermissionActivity;
import com.scandit.datacapture.core.ui.DataCaptureView;
import com.scandit.datacapture.core.ui.style.Brush;
import com.scandit.datacapture.core.ui.viewfinder.RectangularViewfinder;
import com.scandit.datacapture.core.ui.viewfinder.RectangularViewfinderStyle;


public class DraggableActivity extends CameraPermissionActivity implements View.OnTouchListener, ScanViewModel.ResultListener {
    public static Intent getIntent(Context context) {
        return new Intent(context, DraggableActivity.class);
    }
    private FrameLayout draggableView;
    private DataCaptureView dataCaptureView;

    private ScanViewModel viewModel;
    private android.app.AlertDialog dialog = null;

    float dX;
    float dY;
    int lastAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draggable);
        viewModel = new ViewModelProvider(this).get(ScanViewModel.class);

        // Draggable view is a container with the scanner and a textView
        // So when dragging the textView - the whole group will be moved as well
        draggableView = findViewById(R.id.draggable_view);
        draggableView.setOnTouchListener(this);

        initializeAndStartBarcodeScanning();
    }


    @Override
    public boolean onTouch(View view, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                Log.e("FAG","DOWn");
                dX = view.getX() - event.getRawX();
                dY = view.getY() - event.getRawY();
                lastAction = MotionEvent.ACTION_DOWN;
                break;

            case MotionEvent.ACTION_MOVE:
                Log.e("FAG","Move");
                view.setY(event.getRawY() + dY);
                view.setX(event.getRawX() + dX);
                lastAction = MotionEvent.ACTION_MOVE;
                break;

            default:
                return false;
        }
        return true;
    }

    private void initializeAndStartBarcodeScanning() {
        dataCaptureView = DataCaptureView.newInstance(this, viewModel.getDataCaptureContext());

        BarcodeCaptureOverlay overlay =
                BarcodeCaptureOverlay.newInstance(viewModel.getBarcodeCapture(), dataCaptureView);
        Brush brush = new Brush(Color.TRANSPARENT, Color.WHITE, 3f);
        overlay.setBrush(brush);
        overlay.setViewfinder(new RectangularViewfinder(RectangularViewfinderStyle.SQUARE));
        // removing the gestures is optional, as dragging the will be handled with another object,
        // textView in this case, but it may provide a better user experience.
        dataCaptureView.setFocusGesture(null);
        dataCaptureView.setZoomGesture(null);

        // Adding the scanner to the view
        FrameLayout container = findViewById(R.id.container);
        container.addView(dataCaptureView);
    }


    @Override
    protected void onResume() {
        super.onResume();
        // Check for camera permission and request it, if it hasn't yet been granted.
        // Once we have the permission the onCameraPermissionGranted() method will be called.
        requestCameraPermission();
    }

    @Override
    public void onCameraPermissionGranted() {
        resumeFrameSource();
    }

    private void resumeFrameSource() {
        // Switch camera on to start streaming frames.
        // The camera is started asynchronously and will take some time to completely turn on.
        viewModel.setListener(this);
        viewModel.startFrameSource();
        if (!isShowingDialog()) {
            viewModel.resumeScanning();
        }
    }

    private boolean isShowingDialog() {
        return dialog != null && dialog.isShowing();
    }

    @Override
    public void onPause() {
        super.onPause();
        // Switch camera off to stop streaming frames.
        // The camera is stopped asynchronously and will take some time to completely turn off.
        // Until it is completely stopped, it is still possible to receive further results, hence
        // it's a good idea to first disable barcode tracking as well.
        viewModel.setListener(null);
        viewModel.pauseScanning();
        viewModel.stopFrameSource();
    }

    @Override
    public void onCodeScanned(Barcode barcodeResult) {
        String message = getString(
                R.string.scan_result_parametrised,
                SymbologyDescription.create(barcodeResult.getSymbology()).getReadableName(),
                barcodeResult.getData(),
                barcodeResult.getSymbolCount()
        );

        dialog = new AlertDialog.Builder(this)
                .setTitle(getString(R.string.scanned))
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        viewModel.resumeScanning();
                    }
                })
                .create();
        dialog.show();
    }
}